﻿using Couchbase;
using Microsoft.Extensions.Logging;
using Polly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.Interface;
using WebApplication.model;

namespace WebApplication.service
{
    public class Loginservice : ILoginService
    {
        private readonly ILogger<Loginservice> logger;

        public Loginservice(ILogger<Loginservice> logger)
        {
            this.logger = logger;
        }
        public async Task<Logindetails> GetLoginDetails(ICluster cluster, LoginModel model)
        {
           var queryResult = await cluster.QueryAsync<Logindetails>("SELECT email,id,photo,logintype,username,pwd FROM Data ", new Couchbase.Query.QueryOptions());

            List<Logindetails> empList = new List<Logindetails>();

            await foreach (var row in queryResult)
            {
                empList.Add(row);
            }

            var employee = empList.Find(x => x.username == model.username && x.pwd == model.pwd);
            return employee;




        }

        public async Task<Logindetails> PostEmploye(ICluster cluster, Logindetails value)
        {

            var bucket = await cluster.BucketAsync("Logindetails");
            var collection = bucket.DefaultCollection();
            int idvalue = value.id;
            await collection.InsertAsync(idvalue.ToString(), value);


            return null;
        }

        public async Task<ICluster> initialize()
        {
            try
            {
                var policy = Policy.Handle<Exception>()
                   .WaitAndRetryAsync(2, count => TimeSpan.FromSeconds(3));
                await policy.ExecuteAsync(async () =>
                {
                    logger.LogInformation("Retrying...");
                    await connecting();
                });


                return await connecting();


            }
            catch (AuthenticationFailureException)
            {
                logger.LogError("Authentication error");
                throw;
            }
            

        }
        public async Task<ICluster> connecting() {
            var cluster = await Cluster.ConnectAsync("couchbase://localhost", "Administrator", "123456");
            return cluster;
        }
    }
}
