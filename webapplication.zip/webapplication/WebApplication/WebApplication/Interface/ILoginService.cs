﻿using Couchbase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.model;

namespace WebApplication.Interface
{
    public interface ILoginService
{
    Task<ICluster> initialize();
    Task<Logindetails> GetLoginDetails(ICluster cluster, LoginModel model);
        Task<Logindetails> PostEmploye(ICluster cluster, Logindetails value);
    }
}
