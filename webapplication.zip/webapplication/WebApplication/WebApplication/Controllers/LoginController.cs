﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNet.OData;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using WebApplication.Interface;
using WebApplication.model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]


    public class LoginController : ControllerBase
    {
        private readonly ILogger<LoginController> logger;
        private readonly ILoginService _Iservice;
        private readonly ApplicationSettings _appSettings;

        public LoginController(ILoginService Iservice,ILogger<LoginController> logger,IOptions<ApplicationSettings>appSettings)
        {
            this.logger = logger;
            _Iservice = Iservice;
            _appSettings = appSettings.Value;
        }
        // GET: api/<LoginController>
        [HttpGet]
        [AllowAnonymous]

       
        public async Task<LoginCollection> Get([FromQuery]LoginModel model)
        {
            var couchClient = await _Iservice.initialize();
            var loginDetails = await _Iservice.GetLoginDetails(couchClient,model);
            logger.LogInformation ("Login details");
            LoginCollection login = new LoginCollection();

            if(loginDetails == null)
            {
                return login;
            }
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                    {

                      new Claim(ClaimTypes.Name, loginDetails.id.ToString()),
                      new Claim(ClaimTypes.Role, loginDetails.logintype.ToString()),

                    }),
                Expires = DateTime.UtcNow.AddMinutes(2),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_appSettings.JWT_Secret)), SecurityAlgorithms.HmacSha256Signature)
            };
            var tokenHandler = new JwtSecurityTokenHandler();
            var securityToken = tokenHandler.CreateToken(tokenDescriptor);
           
            login.logindetails = loginDetails;



            login.token = tokenHandler.WriteToken(securityToken);
            logger.LogInformation(login.token);
            return login;


        }
        // POST api/<LoginController>
        [HttpPost]
        [Authorize(Roles = "superadmin,admin")]


        public async Task Post([FromBody] Logindetails value)
        {
            var couchClient = await _Iservice.initialize();
            await _Iservice.PostEmploye(couchClient, value);
        
        }


        
        
    }
}
