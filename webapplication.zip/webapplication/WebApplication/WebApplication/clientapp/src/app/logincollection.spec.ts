import { Logincollection } from './logincollection';

describe('Logincollection', () => {
  it('should create an instance', () => {
    expect(new Logincollection()).toBeTruthy();
  });
});
