import { Tokeninfo } from './tokeninfo';

describe('Tokeninfo', () => {
  it('should create an instance', () => {
    expect(new Tokeninfo()).toBeTruthy();
  });
});
