import { Employeedetail } from './employeedetail';

export class Employeecollection {
    employee:Employeedetail[];
    employeecount:number;
}

