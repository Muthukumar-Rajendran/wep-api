export class Empdetails {
    username:string;
    pwd:string;
    id:any;
    email:string;
    skills:string;
    photo:string;
    logintype:string;
    
}
