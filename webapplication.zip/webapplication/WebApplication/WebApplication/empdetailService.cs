﻿namespace WebApplication
{
    internal class empdetailService
    {
    }
}